package chesscore;


public class Player {
	PlayerType player;

	public Player(PlayerType player) {
		this.player = player;
	}

	public PlayerType getPlayer() {
		return player;
	}
}