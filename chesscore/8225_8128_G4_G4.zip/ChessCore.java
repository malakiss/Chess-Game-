/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chesscore;

/**
 *
 * @author ADMIN
 */
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Arrays;
import chesscore.ChessGame;
public class ChessCore {
}


    
           
           
   
